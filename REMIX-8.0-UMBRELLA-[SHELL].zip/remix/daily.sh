[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
 echo "DON'T REBOOT !!!"
echo ""

sleep 2

  echo " 🌿 DAILY MODE 🌿 "

sleep 0.5

echo ""
echo "Installing"
echo ""

sleep 2

cmd set-fixed-performance-mode-enabled false > /dev/null 2>&1 
cmd power set-adaptive-power-saver-enabled true > /dev/null 2>&1 
cmd power set-mode 1 > /dev/null 2>&1 
cmd thermalservice override-status 5 > /dev/null 2>&1 

sleep 2

echo ""
echo "Installed"
echo ""

sleep 0.5

echo ""
echo " Youtube @Yanz_25 "
echo ""