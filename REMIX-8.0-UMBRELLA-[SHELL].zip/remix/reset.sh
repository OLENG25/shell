[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
 echo " REBOOT YOUR DEVICE !!!"
echo ""

sleep 2

  echo " ♻️ RESET MODE ♻️ "

sleep 0.5

echo ""
echo "Installing"
echo ""

sleep 2

cmd set-fixed-performance-mode-enabled false > /dev/null 2>&1 
cmd power set-adaptive-power-saver-enabled false > /dev/null 2>&1 
cmd power set-mode 0 > /dev/null 2>&1 
cmd thermalservice override-status reset > /dev/null 2>&1 

sleep 2

echo ""
echo "Installed"
echo ""

sleep 0.5

echo ""
echo " Youtube @Yanz_25 "
echo ""