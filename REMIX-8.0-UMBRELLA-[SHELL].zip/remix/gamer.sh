[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
 echo "DON'T REBOOT !!!"
echo ""

sleep 2

  echo " 🚀 GAMER MODE 🚀 "

sleep 0.5

echo ""
echo "Installing"
echo ""

sleep 2

cmd set-fixed-performance-mode-enabled true > /dev/null 2>&1 
cmd power set-adaptive-power-saver-enabled true > /dev/null 2>&1 
cmd power set-mode 0 > /dev/null 2>&1 
cmd thermalservice override-status 0 > /dev/null 2>&1 
cmd package bg-dexopt-job > /devnull 2>&1 

sleep 2

echo ""
echo "Installed"
echo ""

sleep 0.5

echo ""
echo " Youtube @Yanz_25 "
echo ""