echo ""
echo "####################################"
echo "#   YANZ 25 COMMUNITY🇮🇩 @YANZ_25   #"
echo "####################################"
echo "#        REMIX 8.0 UMBRELLA        #"
echo "####################################"
echo ""

sleep 2

echo "Installing"

sleep 2

properties=(
  "debug.atrace.tags.enableflags"
  "debug.bt.lowspeed true"
  "debug.cpurend.vsync false"
  "debug.composition.type gpu"
  "debug.cpuprio 7"
  "debug.doze.component 0"
  "debug.duration_tap  0.050"
  "debug.egl.force_fxaa false"
  "debug.egl.force_msaa false"
  "debug.egl.force_smaa false"
  "debug.egl.force_ssaa false"
  "debug.egl.force_taa false"
  "debug.fb.rgb565 1"
  "debug.gpurend.vsync false"
  "debug.gralloc.enable_fb_ubwc 1"
  "debug.gralloc.gfx_ubwc_disable 0"
  "debug.gr.numframebuffers 3"
  "debug.gr.swapinterval 1"
  "debug.gpuprio 7"
  "debug.hwui.drop_shadow_cache_size 6"
  "debug.hwui.disable_vsync false"
  "debug.hwui.enable_bp_cache false"
  "debug.hwui.gradient_cache_size 1"
  "debug.hwui.layer_cache_size 48"
  "debug.hwui.renderer skiagl_threaded"
  "debug.hwui.render_dirty_regions false"
  "debug.hwui.profile false"
  "debug.hwui.path_cache_size 32"
  "debug.hwui.skip_empty_damage true"
  "debug.hwui.show_dirty_regions false"
  "debug.hwui.texture_cache_size 72"
  "debug.hwui.use_buffer_age false"
  "debug.hwui.use_partial_updates true"
  "debug.hwui.use_gpu_pixel_buffers false"
  "debug.hwc.asyncdisp 1"
  "debug.hwc.fakevsync 0"
  "debug.hwc.logvsync 0"
  "debug.ioprio 7"
  "debug.mdpcomp.logs 0"
  "debug.performance.tuning 1"
  "debug.performance.hint 1"
  "debug.performance_schema 1"
  "debug.renderengine.backend skiaglthreaded"
  "debug.sf.showbackground 0"
  "debug.sf.disable_backpressure 1"
  "debug.sf.enable_hwc_vds 0"
  "debug.sf.hw 1"
  "debug.sf.early_phase_offset_ns 500000"
  "debug.sf.early_app_phase_offset_ns 500000"
  "debug.sf.early_gl_phase_offset_ns 3000000"
  "debug.sf.early_gl_app_phase_offset_ns 15000000"
  "debug.sf.showcpu 0"
  "debug.sf.showfps 0"
  "debug.sf.showupdates 0"
  "debug.sf.high_fps_early_phase_offset_ns 6100000"
  "debug.sf.high_fps_early_gl_phase_offset_ns 650000"
  "debug.sf.high_fps_late_app_phase_offset_ns 100000"
  "debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000"
)

for prop in "${properties[@]}"; do
  setprop $prop
done > /dev/null 2>&1 

sleep 2

echo "Installed"

sleep 2

echo ""
echo "DON'T REBOOT !!!"
echo "Youtube @Yanz_25"
echo ""